// Format to local date time 
exports.localDateFormatter = (inputDateStr) => {
  const date = new Date(inputDateStr);
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');  
  const year = date.getFullYear();
  const formatted = `${year}-${month}-${day}`; //2025-04-01
  return formatted;
}

exports.moneyFormatter = (inputtedMoney) => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR'
  }).format(inputtedMoney); // ₹12,34,567.89
}

exports.createHtmlCustomTable = (data) => {
  let customTable = `<b>Transaction History: </b>\n\n`; 
  customTable += `      <b>Date</b>      |     <b>Amount</b>      |      <b>Portfolio</b>\n`; 
  data.forEach(row => {
    customTable += ` ${exports.localDateFormatter(row.date)} | ${exports.moneyFormatter(row.amount)} | ${row.fund_name} \n`;
  });

  console.log(customTable);
  return customTable;
}