
// Starts with 6–9 and has 10 digits
exports.isValidMobile = (number) => {
  const isValid = /^[6-9]\d{9}$/.test(number);
  console.log(`Entered mobile number: ${number} is ${isValid}`)
  return isValid;
}

exports.isValidEmail = (email) => {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
};

exports.isFutureDate = (_date) => {
  return new Date().getTime() <= new Date(_date).getTime();
}