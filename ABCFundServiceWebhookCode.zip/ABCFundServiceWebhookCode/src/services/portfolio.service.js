const data = require('../data/portfolio.data.json');
 
const getSelectedPortfolio = function (_id) {
    return getAll().find(d => d.id == _id);
}

const getPortfolioByName = function (_name) {
    return getAll().find(d => d.folioName == _name);
}

const getAll = function () {
    return data;
}

module.exports = { getAll, getSelectedPortfolio, getPortfolioByName };