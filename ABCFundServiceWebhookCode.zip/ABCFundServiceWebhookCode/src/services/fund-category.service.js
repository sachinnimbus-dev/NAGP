const data = require('../data/fund-category.data.json');

// User selected category data
const getSelectedCategory = function (_category) {
    return getAllFundCategory().find(d => d.category == _category);
}

// List of all categories
const getAllFundCategory = function () {
    return data;
}


module.exports = { getAllFundCategory, getSelectedCategory };