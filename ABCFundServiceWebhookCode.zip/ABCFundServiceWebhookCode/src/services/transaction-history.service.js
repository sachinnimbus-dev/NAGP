const data = require('../data/transaction-history-data.json');

// Load transcations based on user entered mobile number
const getUserTransactions = function (_mobile) {
    console.log('Loading transcations: ' + _mobile);
    return data.find(t => t.mobile == _mobile);
}

// Load all transcations
const getAllTransactions = function () {
    return data;
}

module.exports = { getAllTransactions, getUserTransactions };