const data = require('../data/fund-category.data.json');
const {localDateFormatter } = require('../utils/formatters');
const fs = require('fs');
const path = require('path');


// User selected category data
const saveInvestment = function (_mobile, _amount) { 

    if(_amount == 0) _amount = 3000;
    
    const transationData = {
        "date": localDateFormatter(new Date().toDateString()),
        "amount": _amount ?? 0,
        "fund_name": "Alpha Growth Fund"
    };

    try {
        const filePath = path.join(__dirname, '..', 'data', 'transaction-history-data.json');

        console.log(filePath);
        if (fs.existsSync(filePath)) {
            var trnHistory = fs.readFileSync(filePath, 'utf-8');
            let data = JSON.parse(trnHistory);

            if (data) {
                var rec = data.find(item => item.mobile == _mobile);
                if (rec === undefined) {
                    console.log('New Records');
                    data.push({
                        "mobile": _mobile,
                        "transactions": [
                            transationData
                        ]
                    });
                } else {
                    console.log('Update Records');
                    rec.transactions.push(transationData);
                }

                fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
            } else {
                let newData = [{
                    "mobile": _mobile,
                    "transactions": [
                        transationData
                    ]
                }];
                fs.writeFileSync(filePath, JSON.stringify(newData, null, 2), 'utf-8');
            }
        } else {
            console.log('specified file does not exists');
        }

    } catch (error) {
        // Handle the error
        console.error("Something went wrong:", error.message);
        console.log(error.message);
    }

}


module.exports = { saveInvestment };