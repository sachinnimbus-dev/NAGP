
const { Payload } = require("dialogflow-fulfillment");
const jsonFileService = require("../services/file.service");

const investDetailFunction = (agent) => {

    const globalcontext = agent.context.get('globalcontext');
    const usercontext = agent.context.get('usercontext');
    const mobileNumber = globalcontext ? globalcontext.parameters.mobileNumber : '8733299230';
    const investAmount = usercontext ? usercontext.parameters.investAmount : 0;

    console.log(agent.parameters);

    if (investAmount === undefined || investAmount === 0 || investAmount > 50000) {
        if (investAmount && investAmount > 50000) {
            const warningMessage = {
                "text": "Amount must be < 50,000 and > 0.",
                "parse_mode": "Markdown"
            };
            agent.add(new Payload(agent.TELEGRAM, warningMessage, { rawPayload: false, sendAsMessage: true }));
        }
        else {
            const content = {
                "text": `Enter amount in Rupees:`,
                "reply_markup": {
                    "inline_keyboard": [
                        [
                            {
                                "text": "1000",
                                "callback_data": "investdetail",
                            },
                            {
                                "text": "2000",
                                "callback_data": "investdetail",
                            },
                            {
                                "text": "3000",
                                "callback_data": "investdetail",
                            },
                            {
                                "text": "4000",
                                "callback_data": "investdetail",
                            },
                            {
                                "text": "5000",
                                "callback_data": "investdetail",
                            }
                        ]
                    ],
                },
            }
            agent.add(new
                Payload(agent.TELEGRAM, content,
                    {
                        rawPayload: false,
                        sendAsMessage: true
                    }));

        }
        agent.context.set({ name: 'usercontext', lifespan: 10, parameters: { investAmount: agent.parameters.investAmount } });
        agent.context.set({ name: 'await-invest-amount', lifespan: 5 });
        return;
    }

    console.log('Inside invest detail success');
    jsonFileService.saveInvestment(mobileNumber, investAmount);

    const succContent = {
        "text": " 🙏 <b>Thank you for using our services !</b>",
        "parse_mode": "HTML",
        "reply_markup": {
            "remove_keyboard": true
        }
    }
    agent.add(new
        Payload(agent.TELEGRAM, succContent,
            {
                rawPayload: false,
                sendAsMessage: true
            }));
}

module.exports = { investDetailFunction }