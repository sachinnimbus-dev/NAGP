const { Payload } = require("dialogflow-fulfillment");
const fundCatagoryService = require('../services/fund-category.service');

const fundCategoriesFunction = (agent) => {
    console.log("Inside Fund Categories Function")
    console.log(agent.parameters);
    
    const fulfillmentMessage = {
        "text": "Select one of below fund:",
        "reply_markup": {
            "inline_keyboard": [
                [
                    {
                        "text": "MF001",
                        "callback_data": "fundcategorydetails",
                    },
                    {
                        "text": "MF004",
                        "callback_data": "fundcategorydetails",
                    },
                    {
                        "text": "MF005",
                        "callback_data": "fundcategorydetails",
                    },
                ],
            ],
        },
    }
    agent.add(new
        Payload(agent.TELEGRAM, fulfillmentMessage,
            {
                rawPayload: false,
                sendAsMessage: true
            }));
    return true;
}


module.exports = { fundCategoriesFunction }
