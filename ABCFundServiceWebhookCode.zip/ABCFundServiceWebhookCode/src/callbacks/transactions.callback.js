const { Payload } = require("dialogflow-fulfillment");
const { createHtmlCustomTable } = require("../utils/formatters");
const transactionService = require('../services/transaction-history.service');

function transactionFunction(agent) {  
 
    const globalcontext = agent.context.get('globalcontext');
    const mobile = globalcontext ? globalcontext.parameters.mobileNumber : '5656565656'; 

    console.log(mobile);

    let trnData = transactionService.getUserTransactions(mobile);

    let tableRes;

    if (trnData === undefined || trnData == null) {
        console.log("Response is null or undefined");
        tableRes = `<b>No transaction history found for entered mobile number!!</b>\n`;         
    } else { 
        // As table element is not support in telegram, creating html table look
        tableRes = createHtmlCustomTable(trnData.transactions);
    }

     const content = {
            "text": `${tableRes} \n\n\n Do you want to invest more?`,
            "parse_mode": "HTML",
            "reply_markup": {
                "inline_keyboard": [
                    [
                        {
                            "text": "✅ Yes",
                            "callback_data": "explorefund",
                        },
                        {
                            "text": "❌ No",
                            "callback_data": "complete",
                        }
                    ],
                ],
            },
        }
        agent.add(new Payload(agent.TELEGRAM, content,
            {
                rawPayload: false,
                sendAsMessage: true
            }));
}
 
module.exports = { transactionFunction }