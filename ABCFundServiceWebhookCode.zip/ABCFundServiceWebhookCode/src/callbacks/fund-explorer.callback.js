const { Payload } = require("dialogflow-fulfillment");
const { FUNDCATEGORY } = require('../shared/app-enums');
const fundCatagoryService = require('../services/fund-category.service');


const fundExplorerFunction = (agent) => {
    const categories = fundCatagoryService.getAllFundCategory();
    const categorySuggestions = [];
    categories.forEach(rec => {
        categorySuggestions.push(
            {
                text: `${rec.icon} ${rec.category}`,
                callback_data: "fundCode"
            }
        )
    });

    const content = {
        "text": "<b>Kindly select one of categories to see funds:</b>\n\n",
        "parse_mode": "HTML",
        "reply_markup": {
            "one_time_keyboard": true,
            "inline_keyboard": [
                categorySuggestions
            ],
        },
    }
    agent.add(new
        Payload(agent.TELEGRAM, content,
            {
                rawPayload: false,
                sendAsMessage: true
            }));

}

module.exports = { fundExplorerFunction }