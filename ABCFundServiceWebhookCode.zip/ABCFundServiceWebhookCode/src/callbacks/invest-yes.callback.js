function investYes(agent){
    agent.add('');
    agent.setFollowupEvent({ name: 'Explorer_Fund_Event', "parameters": {} });
}

module.exports = {investYes}