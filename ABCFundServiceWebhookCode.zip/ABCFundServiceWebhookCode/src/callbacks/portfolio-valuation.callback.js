const { isValidMobile } = require('../utils/validators');

function portfolioValuationFunction(agent) {
    const globalcontext = agent.context.get('globalcontext');
    const mobileNumber = globalcontext ? globalcontext.parameters.mobileNumber : undefined;
    console.log("mobileNumber in port:", mobileNumber)

    if (!mobileNumber || !isValidMobile(mobileNumber)) {      
        agent.add('');
        agent.context.set({ name: 'flowcontext', lifespan: 2, parameters: { flow: 'portfolio' } });
        agent.setFollowupEvent({ name: 'Mobile_Capture_Event', "parameters": {} });
        return;
    }

    agent.add('');
    agent.setFollowupEvent({ name: 'Extract_Folio_Event', "parameters": {} })
}

module.exports = { portfolioValuationFunction }