const { Payload } = require("dialogflow-fulfillment");
const { isValidMobile } = require('../utils/validators');

const mobileCaptureFunction = (agent) => {
    console.log('Inside mobile Capture Function');
    console.log(agent.parameters);

    if (!agent.parameters || agent.parameters.mobileNumber === '' || !isValidMobile(agent.parameters.mobileNumber)) {
        if (agent.parameters.mobileNumber) {
            console.log('Validation');
            const validMobile = isValidMobile(agent.parameters.mobileNumber);
            if (!validMobile) {
                console.log('Validation - false');
                const telegramMessage = {
                    "text": "That doesn’t look like a valid mobile number.\nPlease enter a valid 10-digit number starting with 6–9.",
                    "parse_mode": "HTML"
                };
                agent.add(new Payload(agent.TELEGRAM, telegramMessage, { rawPayload: false, sendAsMessage: true }));
                //agent.add('That doesn’t look like a valid mobile number. Please enter a valid 10-digit number starting with 6–9.');
            } else {
                agent.add('');
            }
        } else {
            agent.add('');
        }
        agent.context.set({ name: 'globalcontext', lifespan: 11, parameters: { mobileNumber: agent.parameters.mobileNumber } });
        agent.context.set({ name: 'awaiting_valid_phone', lifespan: 1 });
        return;
    } else {

        const mobilePayload = {
            telegram: {
                text: `Got it! Your mobile number is ${agent.parameters.mobileNumber}.`
            }
        };

        agent.add(new Payload(agent.TELEGRAM, mobilePayload, { rawPayload: false, sendAsMessage: false }));

        agent.context.set({ name: 'globalcontext', lifespan: 11, parameters: { mobileNumber: agent.parameters.mobileNumber } });
    }

    const flowcontext = agent.context.get('flowcontext');
    const flow = flowcontext ? flowcontext.parameters.flow : undefined;

    console.log(`flow: ${flow}`);

    if (flow === 'invest') {
        agent.setFollowupEvent({ name: 'Invest_Detail_Event', "parameters": {} });
    }
    else if (flow === 'transationHistory') {
        agent.setFollowupEvent({ name: 'Transation_History', "parameters": {} });
    }
    else {
        agent.setFollowupEvent({ name: 'Portfolio_Event', "parameters": {} })
    }

}

module.exports = { mobileCaptureFunction }
