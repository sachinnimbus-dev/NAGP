const { Payload } = require("dialogflow-fulfillment");
const fundCatagoryService = require('../services/fund-category.service');

const fundCategoriesDetailFunction = (agent) => {
    console.log("Inside Fund Categories Detail Function");
    console.log(agent.parameters);
    const content = {
        "text": `<b>Selected Fund Details:</b>\nIt has ratio as 30%(Debt)-30%(Large Cap Equity)-20%(Mid Cap Equity)-20%(Small Cap Equity) with a 15% CAGR.\n\n\nFor more details: <b><a href="https://google.com">Click here 🔗</a> </b>`,
        "parse_mode": "HTML",
        "reply_markup": {
            "inline_keyboard": [
                [
                    {
                        "text": "💵 Invest",
                        "callback_data": "Investmoney",
                    },
                    {
                        "text": "🏠 Return to Main Menu",
                        "callback_data": "Hi",
                    }
                ],
            ],
        },
    }
    agent.add(new Payload(agent.TELEGRAM, content,
        {
            rawPayload: false,
            sendAsMessage: true
        }));
}

module.exports = { fundCategoriesDetailFunction }
