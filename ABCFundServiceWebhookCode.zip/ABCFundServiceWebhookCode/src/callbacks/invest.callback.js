const { isValidMobile } = require('../utils/validators');

const investFunction = (agent) => {
    const globalcontext = agent.context.get('globalcontext');
    const mobileNumber = globalcontext ? globalcontext.parameters.mobileNumber : undefined;

    if (!mobileNumber
        || !isValidMobile(mobileNumber)
    ) {
        agent.add('');
        agent.context.set({ name: 'flowcontext', lifespan: 2, parameters: { flow: 'invest' } });
        agent.setFollowupEvent({ name: 'Mobile_Capture_Event', "parameters": {} });
        return;
    }

    agent.add('');
    agent.setFollowupEvent({ name: 'Invest_Detail_Event', "parameters": {} })
}

module.exports = { investFunction }