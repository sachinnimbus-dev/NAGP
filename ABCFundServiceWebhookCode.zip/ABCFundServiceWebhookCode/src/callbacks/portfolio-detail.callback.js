const portfolioService = require("../services/portfolio.service");
const { localDateFormatter, moneyFormatter } = require("../utils/formatters");
const { Payload } = require("dialogflow-fulfillment");

const folioFunction = (agent) => {
    const inputContext = agent.context.get('portfoliocontext');
    const folioNumber = inputContext ? inputContext.parameters.folioNumber : undefined;
    if (!folioNumber) {
        agent.add('')
        agent.setFollowupEvent({ name: 'Portfolio_Event', "parameters": {} });
    }
    else {
        let content;
        let portData = portfolioService.getPortfolioByName(inputContext.parameters.folioNumber);
        if (portData == undefined) {
            content = {
                "text": `<b>Your Portfolio ${folioNumber} is not valid. Wanted to try again?\n`,
                "parse_mode": "HTML",
                "reply_markup": {
                    "inline_keyboard": [
                        [
                            {
                                "text": "✅ Yes",
                                "callback_data": "portfolio",
                            },
                            {
                                "text": "❌ No",
                                "callback_data": "complete",
                            }
                        ]
                    ]
                }
            }
        } else {
            content = {
                "text": `<b>Your Portfolio ${folioNumber} valuation is ${moneyFormatter(portData.totalAmount)} on ${localDateFormatter(new Date().toUTCString())}</b>\n\n\n Thanks for completing the process 🙏`,
                "parse_mode": "HTML",
                "reply_markup": {
                    "remove_keyboard": true
                },
            }
        }

        agent.add(new Payload(agent.TELEGRAM, content,
            {
                rawPayload: false,
                sendAsMessage: true
            }));
    }
}
module.exports = { folioFunction }