const { Payload } = require("dialogflow-fulfillment");
const { isValidMobile, isFutureDate } = require('../utils/validators');

function transationHistoryFunction(agent) {
    const globalcontext = agent.context.get('globalcontext');
    const mobileNumber = globalcontext ? globalcontext.parameters.mobileNumber : undefined;
    const datePeriod = agent.parameters.datePeriod;
    console.log('Inside Transation History');
    console.log(mobileNumber);
    if (!mobileNumber || !isValidMobile(mobileNumber)) {
        agent.add('');
         agent.context.set({ name: 'flowcontext', lifespan: 5, parameters: { flow: 'transationHistory' } });
        agent.setFollowupEvent({ name: 'Mobile_Capture_Event', "parameters": {} });
        return;
    }
 
    if (!agent.parameters || agent.parameters.datePeriod === '' || isFutureDate(datePeriod.startDate)) {
        const content = {
            "text": "Please provide a date period.",
            "reply_markup": {
                "one_time_keyboard": true,
                "inline_keyboard": [
                    [
                        {
                            "text": "Current Financial Year",
                            "callback_data": "Current year",
                        },
                        {
                            "text": "Previous Financial Year",
                            "callback_data": "Last year",
                        }
                    ],
                ],
            },
        }
        agent.add(new
            Payload(agent.TELEGRAM, content,
                {
                    rawPayload: false, sendAsMessage:
                        true
                }));
        return
    }

    agent.add('')
    agent.setFollowupEvent({ name: 'ListOfTransactionEvent', "parameters": {} });
}
 
module.exports = { transationHistoryFunction }