const { Payload } = require("dialogflow-fulfillment");
const portfolioService = require("../services/portfolio.service");

const captureFolioFunction = (agent) => {
    console.log("coming here:", agent.parameters)
    if (!agent.parameters || !agent.parameters.folioNumber || agent.parameters.folioNumber === '') {
        folioFullfillment(agent);
        return true;
    }
    console.log(agent.parameters.folioNumber);
    
    const selectedFundCategory = portfolioService.getPortfolioByName(agent.parameters.folioNumber)
    console.log(selectedFundCategory);
    if (!selectedFundCategory) { 
        agent.add('')
        agent.setFollowupEvent({ name: 'Extract_Folio_Event', "parameters": {} });
        return;
    }

    agent.add('')
    agent.context.set({ name: 'portfoliocontext', lifespan: 1, parameters: { folioNumber: agent.parameters.folioNumber } });
    agent.setFollowupEvent({ name: 'Folio_Event', "parameters": {} });
}

function folioFullfillment(agent) {

    const keyBoardSuggestions = [];
    portfolioService.getAll().forEach(rec => {
        keyBoardSuggestions.push(
            {
                text: rec.folioName,
                callback_data: rec.folioName
            }
        )
    })
    console.log(keyBoardSuggestions);
    const content = {
        "text": `Kindly select one of your portfolios.`,
        "reply_markup": {
            "inline_keyboard": [
                keyBoardSuggestions
            ],
        },
    }
    agent.add(new
        Payload(agent.TELEGRAM, content,
            {
                rawPayload: false,
                sendAsMessage: true
            }));
}

module.exports = { captureFolioFunction }