const { Payload } = require("dialogflow-fulfillment");

const completeFunction = (agent) => {
    agent.add('');
    const content = {
        "text": "🙏 <b>Thank you for using our services. </b>",
        "parse_mode": "HTML",
        "reply_markup": {
            "remove_keyboard": true // This removes any custom keyboard
        }
    }
    agent.add(new
        Payload(agent.TELEGRAM, content,
            {
                rawPayload: false,
                sendAsMessage: true
            }));
}

module.exports = { completeFunction }