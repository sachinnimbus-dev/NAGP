const { Payload } = require("dialogflow-fulfillment");

const welcomeFunction = (agent) =>{

    //clear all context here..
    agent.context.set({ name: 'usercontext', lifespan: 0 }); 
    agent.context.set({ name: 'globalcontext', lifespan: 0 }); 
    agent.context.set({ name: 'flowcontext', lifespan: 0 }); 

    const content = {
        "text": "Hi, welcome to ABC Mutual Fund Services. What service would you like to use?",
        "reply_markup": {
            "inline_keyboard": [
                [
                    {                        
                        "text": "Portfolio Valuation",
                        "callback_data": "portfolio",
                    },
                    {
                        "text": "Explore Funds",
                        "callback_data": "explorefund",
                    },
                    {
                        "text": "Transaction History",
                        "callback_data": "transactionhistory",
                    },
                ],
            ],
        },
    }
    agent.add(new
        Payload(agent.TELEGRAM, content,
            {
                rawPayload: false, sendAsMessage:
                    true
            }));
}

module.exports = { welcomeFunction }