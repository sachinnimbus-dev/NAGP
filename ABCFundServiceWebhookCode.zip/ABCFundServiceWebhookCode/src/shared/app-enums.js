
const FUNDCATEGORY = Object.freeze({
    EQUITY: 'Equity',
    DEBT: 'Debt',
    HYBRID: 'Hybrid'
});

module.exports = { FUNDCATEGORY };