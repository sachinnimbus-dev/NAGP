module.exports = {
  APP_NAME: 'ABCMutualFundServiceAPI',
  PORT: 8080, 
  MESSAGES: {
    INVALID_PHONE: 'Please enter a valid mobile number.',
    SUCCESS: 'Operation successful.',
    ERROR: 'Something went wrong. Please try again.'
  }
};