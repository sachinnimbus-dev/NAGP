const express = require('express')
const constants = require('./src/shared/app-constants')
const { WebhookClient } = require('dialogflow-fulfillment');
const { welcomeFunction } = require('./src/callbacks/welcome.callback');
const { fallbackFunction } = require('./src/callbacks/fallback');
const { fundExplorerFunction } = require('./src/callbacks/fund-explorer.callback');
const { fundCategoriesFunction } = require('./src/callbacks/fund-categories.callback');
const { fundCategoriesDetailFunction } = require('./src/callbacks/fund-categories-detail.callback');
const { portfolioValuationFunction } = require('./src/callbacks/portfolio-valuation.callback');
const { transationHistoryFunction } = require('./src/callbacks/transaction-history.callback');
const { investFunction } = require('./src/callbacks/invest.callback');
const { mobileCaptureFunction } = require('./src/callbacks/mobile-capture.callback');
const { folioFunction } = require('./src/callbacks/portfolio-detail.callback');
const { transactionFunction } = require('./src/callbacks/transactions.callback');
const { investYes } = require('./src/callbacks/invest-yes.callback');
const { captureFolioFunction } = require('./src/callbacks/portfolio.callback'); 
const { completeFunction } = require('./src/callbacks/complete-callback'); 
const { investDetailFunction } = require('./src/callbacks/invest-detail.callback');

const app = express()

app.get('/', (req, res) =>
    res.send('Servcer is up and running')
);

const intentMappingData = [
    {
        intentName: 'Default Welcome Intent',
        functionName: welcomeFunction
    },
    {
        intentName: 'Default Fallback Intent',
        functionName: fallbackFunction
    },{
        intentName: 'Portfolio Valuation Intent',
        functionName: portfolioValuationFunction
    },
    {
        intentName: 'Extract Folio Number Intent',
        functionName: captureFolioFunction
    },
    {
        intentName: 'Transaction History Intent',
        functionName: transationHistoryFunction
    },
    {
        intentName: 'List of Transaction Intent - yes',
        functionName: investYes
    },
    {
        intentName: 'List of Transaction Intent',
        functionName: transactionFunction
    },
    {
        intentName: 'Explorer Fund Intent',
        functionName: fundExplorerFunction
    },
    {
        intentName: 'Fund Categories Intent',
        functionName: fundCategoriesFunction
    },
    {
        intentName: 'Fund Categories Detail Intent',
        functionName: fundCategoriesDetailFunction
    },
    {
        intentName: 'Invest Intent',
        functionName: investFunction
    }, 
    {
        intentName: 'Invest Detail Intent',
        functionName: investDetailFunction 
    },
    {
        intentName: 'Mobile Number Intent',
        functionName: mobileCaptureFunction
    },
    {
        intentName: 'Portfolio Intent',
        functionName: folioFunction
    },
    {
        intentName: 'Complete Intent',
        functionName: completeFunction
    }  
]


app.post('/dialogFlow', express.json(), (request, response) => {
    const agent = new WebhookClient({ request, response });
    let intentMap = new Map();
    intentMappingData.forEach(rec => {
        intentMap.set(rec.intentName, rec.functionName);
    })
    agent.handleRequest(intentMap);
})

const PORT =  process.env.port || constants.PORT;
app.listen(PORT)
console.log(`app is online at ${PORT}`);